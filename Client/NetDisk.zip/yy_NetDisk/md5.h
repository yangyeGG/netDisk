#ifndef _MD5_H_
#define _MD5_H_
 
#ifdef __cplusplus
extern "C" {
#endif

extern char*  md5_encrypt(const void* data, int size); 

#ifdef __cplusplus
}
#endif

#endif
